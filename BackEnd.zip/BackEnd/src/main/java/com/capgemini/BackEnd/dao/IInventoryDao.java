package com.capgemini.BackEnd.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.BackEnd.model.Inventory;


@Repository("inventoryDao")
public interface IInventoryDao extends JpaRepository<Inventory, Integer>{

}
