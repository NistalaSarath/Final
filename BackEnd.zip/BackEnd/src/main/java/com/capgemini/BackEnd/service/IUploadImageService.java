package com.capgemini.BackEnd.service;

import java.util.List;

import com.capgemini.BackEnd.model.ProductImages;

public interface IUploadImageService {

	public int getMaxId();

	public void save(ProductImages productimages);

	public List<ProductImages> getAllProducts();

	

}
