package com.capgemini.BackEnd.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.BackEnd.model.Inventory;




public interface IInventoryService {

	public List<Inventory> getAll();

}
